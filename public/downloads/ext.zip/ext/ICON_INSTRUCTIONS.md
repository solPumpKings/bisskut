# 🪂 Adding Your Parachute/Airdrop Image as Favicon

## Quick Instructions:

### Option 1: Use the Icon Converter (Easiest)
1. **Open** `icon_converter.html` in your browser
2. **Upload** your parachute/airdrop image
3. **Click** "Generate Icons" 
4. **Download** all icon sizes (16x16, 32x32, 48x48, 128x128)
5. **Replace** the files in the `icons/` folder:
   - `icons/icon16.png`
   - `icons/icon32.png` 
   - `icons/icon48.png`
   - `icons/icon128.png`
6. **Reload** the extension in Chrome

### Option 2: Manual Conversion
1. **Save** your parachute image as `original_icon.png`
2. **Resize** it to these sizes using any image editor:
   - 16x16 pixels → `icon16.png`
   - 32x32 pixels → `icon32.png`
   - 48x48 pixels → `icon48.png`
   - 128x128 pixels → `icon128.png`
3. **Place** all files in the `icons/` folder
4. **Reload** the extension

### Option 3: Online Tools
1. Go to **favicon.io** or **realfavicongenerator.net**
2. **Upload** your parachute image
3. **Generate** all sizes
4. **Download** and extract to `icons/` folder
5. **Rename** files to match our naming convention

## ✅ What's Already Updated:
- ✅ `manifest.json` updated with all icon sizes
- ✅ Icon converter tool created
- ✅ Proper file structure in place

## 🔄 After Replacing Icons:
1. Go to `chrome://extensions/`
2. Click **"Reload"** on Aster DEX extension
3. Your parachute/airdrop icon will appear!

## 📁 Current Icon Files to Replace:
```
icons/
├── icon16.png   (16x16 - browser toolbar)
├── icon32.png   (32x32 - extension manager)
├── icon48.png   (48x48 - extension management page)
└── icon128.png  (128x128 - Chrome Web Store)
```

The parachute/airdrop theme is perfect for Aster DEX! 🚀