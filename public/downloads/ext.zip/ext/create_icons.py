import os
from PIL import Image
import requests
from io import BytesIO

# Create the icons directory if it doesn't exist
icons_dir = "icons"
if not os.path.exists(icons_dir):
    os.makedirs(icons_dir)

# Create a sample parachute/airdrop icon based on the description
# Since I can't directly save the uploaded image, I'll create a similar design
def create_airdrop_icon():
    # Create a 128x128 image with dark background
    img = Image.new('RGBA', (128, 128), (45, 45, 45, 255))
    
    # For now, create a simple colored square as placeholder
    # The actual image will need to be manually saved
    # This is just to create the file structure
    
    # Save as 128x128
    img.save(os.path.join(icons_dir, "icon128.png"))
    
    # Resize and save other sizes
    img_48 = img.resize((48, 48), Image.Resampling.LANCZOS)
    img_48.save(os.path.join(icons_dir, "icon48.png"))
    
    img_32 = img.resize((32, 32), Image.Resampling.LANCZOS)
    img_32.save(os.path.join(icons_dir, "icon32.png"))
    
    img_16 = img.resize((16, 16), Image.Resampling.LANCZOS)
    img_16.save(os.path.join(icons_dir, "icon16.png"))
    
    print("Icon files created. Please replace icon128.png with your parachute image.")

if __name__ == "__main__":
    create_airdrop_icon()