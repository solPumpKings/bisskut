// Injected Script for Aster DEX Extension - BNB Smart Chain
// This file is kept for compatibility but main functionality is in injected-standalone.js

(function () {
    'use strict';

    console.log('Aster DEX injected script loaded for BNB Smart Chain');
    
    // Simple redirect to standalone version
    if (window.AsterDEXInjected) {
        console.log('AsterDEX standalone script already loaded');
    } else {
        console.log('Loading AsterDEX standalone functionality...');
    }

})();
