// Injected Script for DropX Extension - BNB Smart Chain
// This file is kept for compatibility but main functionality is in injected-standalone.js

(function () {
    'use strict';

    console.log('DropX injected script loaded for BNB Smart Chain');
    
    // Simple redirect to standalone version
    if (window.DropXInjected) {
        console.log('DropX standalone script already loaded');
    } else {
        console.log('Loading DropX standalone functionality...');
    }

})();
