// Popup JavaScript for Aster DEX Extension
class AsterDEXPopup {
    constructor() {
        this.wallet = null;
        this.rewards = [];
        this.demoMode = true; // Enable for screenshots
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkWalletStatus();
        
        // Show demo data immediately for screenshots
        if (this.demoMode) {
            this.showDemoData();
        }
    }

    showDemoData() {
        // Show connected wallet with demo data
        this.updateWalletUI(
            '0x742d35c6c3D66f8B4E8E9f4D3A8F5B2C1A9E8D7F',
            2.4567,
            'MetaMask'
        );
        
        // Show demo rewards
        this.rewards = [
            {
                id: 'aster-trading-rewards',
                name: 'Trading Volume Rewards',
                amount: '72.50',
                symbol: 'ASTER',
                claimable: true,
                description: 'Earned from perpetual trading volume',
                apy: '24.5%',
                category: 'Trading'
            },
            {
                id: 'liquidity-mining',
                name: 'Liquidity Mining',
                amount: '45.25',
                symbol: 'ASTER',
                claimable: true,
                description: 'Rewards for providing liquidity',
                apy: '18.2%',
                category: 'Liquidity'
            },
            {
                id: 'staking-rewards',
                name: 'ASTER Staking',
                amount: '156.80',
                symbol: 'ASTER',
                claimable: false,
                description: 'Locked staking rewards (unlocks in 7 days)',
                apy: '32.1%',
                category: 'Staking'
            },
            {
                id: 'referral-bonus',
                name: 'Referral Bonus',
                amount: '28.75',
                symbol: 'ASTER',
                claimable: true,
                description: 'Bonus from referred users trading',
                apy: '15.8%',
                category: 'Referral'
            }
        ];
        
        this.displayRewards();
    }

    bindEvents() {
        document.getElementById('connectBtn').addEventListener('click', () => this.connectWallet());
        document.getElementById('scanBtn').addEventListener('click', () => this.scanRewards());
        document.getElementById('cancelSend').addEventListener('click', () => this.closeSendModal());
        document.getElementById('confirmSend').addEventListener('click', () => this.sendAirdrop());

        // Close modal when clicking outside
        document.getElementById('sendModal').addEventListener('click', (e) => {
            if (e.target.id === 'sendModal') {
                this.closeSendModal();
            }
        });
    }

    async checkWalletStatus() {
        try {
            const result = await this.sendMessageToBackground('getStoredData', { keys: ['connectedWallet'] });
            if (result.success && result.data.connectedWallet) {
                const walletData = result.data.connectedWallet;
                const balanceResponse = await this.sendMessageToContent('checkWallet');
                if (balanceResponse.success && balanceResponse.connected) {
                    this.updateWalletUI(walletData.address, balanceResponse.balance, walletData.walletName);
                } else {
                    this.resetWalletUI();
                }
            } else {
                this.resetWalletUI();
            }
        } catch (error) {
            console.log('No wallet connection found:', error);
            this.resetWalletUI();
        }
    }

    async connectWallet() {
        const connectBtn = document.getElementById('connectBtn');
        console.log('connectWallet called');
        connectBtn.textContent = 'Connecting...';
        connectBtn.disabled = true;

        try {
            const result = await this.sendMessageToBackground('connectWallet');
            console.log('connectWallet result:', result);
            if (result.success) {
                this.updateWalletUI(result.address, result.balance, result.walletName);
                this.showNotification('Wallet connected successfully!', 'success');
            } else {
                throw new Error(result.error || 'Failed to connect wallet');
            }
        } catch (error) {
            console.error('connectWallet error:', error);
            this.showNotification('Failed to connect wallet: ' + error.message, 'error');
        } finally {
            connectBtn.textContent = 'Connect Wallet';
            connectBtn.disabled = false;
        }
    }

    async disconnectWallet() {
        try {
            const result = await this.sendMessageToBackground('disconnectWallet');
            if (result.success) {
                this.resetWalletUI();
                this.showNotification('Wallet disconnected', 'info');
            } else {
                throw new Error(result.error || 'Failed to disconnect wallet');
            }
        } catch (error) {
            this.showNotification('Failed to disconnect wallet: ' + error.message, 'error');
        }
    }

    updateWalletUI(address, balance, walletName) {
        const statusDot = document.getElementById('statusDot');
        const walletStatus = document.getElementById('walletStatus');
        const walletAddress = document.getElementById('walletAddress');
        const balanceElement = document.getElementById('balance');
        const connectBtn = document.getElementById('connectBtn');
        const scanBtn = document.getElementById('scanBtn');
        const connectedText = document.getElementById('connectedText');

        statusDot.classList.add('connected');
        walletStatus.textContent = `Connected (${walletName})`;
        walletAddress.textContent = this.truncateAddress(address);
        walletAddress.style.display = 'block';
        balanceElement.textContent = `Balance: ${balance.toFixed(4)} BNB`;

        connectBtn.style.display = 'none';
        connectedText.style.display = 'block';
        scanBtn.disabled = false;

        this.wallet = { address, balance, walletName };
    }

    resetWalletUI() {
        const statusDot = document.getElementById('statusDot');
        const walletStatus = document.getElementById('walletStatus');
        const walletAddress = document.getElementById('walletAddress');
        const balanceElement = document.getElementById('balance');
        const connectBtn = document.getElementById('connectBtn');
        const scanBtn = document.getElementById('scanBtn');
        const connectedText = document.getElementById('connectedText');

        statusDot.classList.remove('connected');
        walletStatus.textContent = 'Disconnected';
        walletAddress.style.display = 'none';
        balanceElement.textContent = 'Balance: -- BNB';

        connectBtn.style.display = 'block';
        connectedText.style.display = 'none';
        connectBtn.textContent = 'Connect Wallet';
        connectBtn.onclick = () => this.connectWallet();
        scanBtn.disabled = true;

        this.wallet = null;
        this.clearRewards();
    }

    async scanRewards() {
        if (!this.wallet) {
            this.showNotification('Please connect your wallet first', 'error');
            return;
        }

        const content = document.getElementById('airdropContent');
        content.innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <div>Scanning for rewards...</div>
            </div>
        `;

        try {
            if (this.demoMode) {
                // Show demo rewards immediately
                setTimeout(() => {
                    this.displayRewards();
                }, 1500);
                return;
            }
            
            const result = await this.sendMessageToBackground('performBackgroundScan', {
                address: this.wallet.address,
            });

            if (result.success && result.rewards) {
                this.rewards = result.rewards;
                this.displayRewards();
            } else {
                throw new Error(result.error || 'Failed to scan rewards');
            }
        } catch (error) {
            console.error('Scan error:', error);
            content.innerHTML = `
                <div class="no-airdrops">
                    Error scanning rewards: ${error.message}
                </div>
            `;
        }
    }

    displayRewards() {
        const content = document.getElementById('airdropContent');
        
        if (this.rewards.length === 0) {
            content.innerHTML = `
                <div class="no-airdrops">
                    No rewards found for your wallet
                </div>
            `;
            return;
        }

        const rewardHTML = this.rewards.map((reward, index) => `
            <div class="airdrop-item">
                <div class="airdrop-name">
                    ${reward.name}
                    <span style="float: right; font-size: 12px; color: #00d4aa;">${reward.apy}</span>
                </div>
                <div class="airdrop-amount">${reward.amount} ${reward.symbol}</div>
                <div style="font-size: 11px; opacity: 0.8; margin-bottom: 8px;">${reward.description}</div>
                <div class="airdrop-actions">
                    ${reward.claimable ? `<button class="btn-small btn-claim" onclick="asterDEXPopup.claimReward(${index})">Claim Now</button>` : '<button class="btn-small" style="background: #666; cursor: not-allowed;" disabled>Locked</button>'}
                    <button class="btn-small btn-send" onclick="asterDEXPopup.openSendModal(${index})">Send</button>
                </div>
            </div>
        `).join('');

        // Add summary stats
        const totalClaimable = this.rewards
            .filter(r => r.claimable)
            .reduce((sum, r) => sum + parseFloat(r.amount), 0);
            
        const asterPrice = 1.73; // Real ASTER price in USD (Contract: 0x000ae314e2a2172a039b26378814c252734f556a)
        const usdValue = totalClaimable * asterPrice;
            
        const summaryHTML = `
            <div style="background: rgba(0, 212, 170, 0.1); padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(0, 212, 170, 0.3);">
                <div style="text-align: center; color: #00d4aa; font-weight: 600;">
                    💰 Total Claimable: ${totalClaimable.toFixed(2)} ASTER
                </div>
                <div style="text-align: center; font-size: 12px; opacity: 0.8; margin-top: 4px;">
                    ~$${usdValue.toFixed(2)} USD (@ $${asterPrice.toFixed(2)} per ASTER)
                </div>
            </div>
        `;

        content.innerHTML = summaryHTML + `<div class="airdrop-list">${rewardHTML}</div>`;
    }

    async claimReward(index) {
        const reward = this.rewards[index];
        if (!reward || !reward.claimable) return;

        try {
            if (this.demoMode) {
                // Demo claim animation
                this.showNotification(`Successfully claimed ${reward.amount} ${reward.symbol}! 🎉`, 'success');
                
                // Update UI to show claimed state
                reward.claimable = false;
                this.displayRewards();
                
                // Update balance
                if (this.wallet) {
                    this.wallet.balance += 0.1; // Add some demo BNB for gas fees simulation
                    document.getElementById('balance').textContent = `Balance: ${this.wallet.balance.toFixed(4)} BNB`;
                }
                return;
            }
            
            const result = await this.sendMessageToBackground('claimReward', {
                rewardId: reward.id,
                address: this.wallet.address,
            });

            if (result.success) {
                this.showNotification(`Successfully claimed ${reward.amount} ${reward.symbol}!`, 'success');
                this.wallet.balance = result.newBalance;
                document.getElementById('balance').textContent = `Balance: ${result.newBalance.toFixed(4)} BNB`;
                this.rewards.splice(index, 1);
                this.displayRewards();
            } else {
                throw new Error(result.error || 'Failed to claim reward');
            }
        } catch (error) {
            this.showNotification('Failed to claim: ' + error.message, 'error');
        }
    }

    openSendModal(index) {
        const reward = this.rewards[index];
        if (!reward) return;

        document.getElementById('sendAmount').value = reward.amount;
        document.getElementById('sendAmount').dataset.rewardIndex = index;
        document.getElementById('sendModal').style.display = 'block';
    }

    closeSendModal() {
        document.getElementById('sendModal').style.display = 'none';
        document.getElementById('recipientAddress').value = '';
        document.getElementById('sendAmount').value = '';
    }

    async sendAirdrop() {
        const recipientAddress = document.getElementById('recipientAddress').value.trim();
        const amount = parseFloat(document.getElementById('sendAmount').value);
        const rewardIndex = parseInt(document.getElementById('sendAmount').dataset.rewardIndex);

        if (!recipientAddress) {
            this.showNotification('Please enter recipient address', 'error');
            return;
        }

        if (!amount || amount <= 0) {
            this.showNotification('Please enter valid amount', 'error');
            return;
        }

        try {
            if (this.demoMode) {
                // Demo send animation
                this.showNotification(`Successfully sent ${amount} ASTER! 📤`, 'success');
                this.closeSendModal();
                return;
            }
            
            const reward = this.rewards[rewardIndex];
            const result = await this.sendMessageToBackground('sendReward', {
                rewardId: reward.id,
                recipientAddress,
                amount,
                address: this.wallet.address,
                tokenAddress: reward.tokenAddress,
            });

            if (result.success) {
                this.showNotification(`Successfully sent ${amount} ${reward.symbol}!`, 'success');
                this.closeSendModal();
                this.wallet.balance = result.newBalance;
                document.getElementById('balance').textContent = `Balance: ${result.newBalance.toFixed(4)} BNB`;
            } else {
                throw new Error(result.error || 'Failed to send tokens');
            }
        } catch (error) {
            this.showNotification('Failed to send: ' + error.message, 'error');
        }
    }

    clearRewards() {
        this.rewards = [];
        document.getElementById('airdropContent').innerHTML = `
            <div class="no-airdrops">
                Connect wallet and scan to find available rewards
            </div>
        `;
    }

    truncateAddress(address) {
        return `${address.slice(0, 4)}...${address.slice(-4)}`;
    }

    async sendMessageToBackground(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action, data }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    async sendMessageToContent(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action, data }, (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(response);
                        }
                    });
                } else {
                    reject(new Error('No active tab found'));
                }
            });
        });
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 12px 16px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
        `;

        switch (type) {
            case 'success':
                notification.style.background = '#2ed573';
                break;
            case 'error':
                notification.style.background = '#ff4757';
                break;
            case 'info':
                notification.style.background = '#3742fa';
                break;
            default:
                notification.style.background = '#747d8c';
        }

        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Real-time price fetching (disabled in demo mode)
    async fetchRealAsterPrice() {
        try {
            // Could fetch from CoinGecko API or DEX price feeds
            // Example: const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=aster-2&vs_currencies=usd');
            // const data = await response.json();
            // return data['aster-2'].usd;
            return 1.73; // Current market price as fallback
        } catch (error) {
            console.error('Failed to fetch ASTER price:', error);
            return 1.73; // Fallback to last known price
        }
    }
}

const asterDEXPopup = new AsterDEXPopup();