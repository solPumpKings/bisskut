// Popup JavaScript for DropX Extension
class DropXPopup {
    constructor() {
        this.wallet = null;
        this.rewards = [];
    this.demoMode = false; // Demo mode disabled — use real functionality
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkWalletStatus();
        
        // Use real wallet check flow
        this.checkRealWalletConnection();
    }

    showDemoData() {
        // Show connected wallet with demo data
        this.updateWalletUI(
            '0x742d35c6c3D66f8B4E8E9f4D3A8F5B2C1A9E8D7F',
            2.4567,
            'MetaMask'
        );
        
        // Show demo airdrops
        this.rewards = [
            {
                id: 'pancakeswap-airdrop',
                name: 'PancakeSwap Airdrop',
                amount: '125.50',
                symbol: 'CAKE',
                claimable: true,
                description: 'Free CAKE tokens for active traders',
                apy: '18.5%',
                category: 'Airdrop'
            },
            {
                id: 'bsc-ecosystem-rewards',
                name: 'BSC Ecosystem Rewards',
                amount: '89.75',
                symbol: 'BNB',
                claimable: true,
                description: 'Rewards for BSC ecosystem participation',
                apy: '12.8%',
                category: 'Ecosystem'
            },
            {
                id: 'defi-yield-farming',
                name: 'DeFi Yield Farming',
                amount: '267.30',
                symbol: 'BUSD',
                claimable: false,
                description: 'Locked yield farming rewards (unlocks in 3 days)',
                apy: '24.1%',
                category: 'Yield'
            },
            {
                id: 'nft-holder-bonus',
                name: 'NFT Holder Bonus',
                amount: '48.25',
                symbol: 'TOKEN',
                claimable: true,
                description: 'Bonus rewards for NFT collection holders',
                apy: '15.2%',
                category: 'NFT'
            }
        ];
        
        this.displayAirdrops();
    }

    bindEvents() {
        document.getElementById('connectBtn').addEventListener('click', () => this.connectWallet());
        document.getElementById('scanBtn').addEventListener('click', () => this.scanAirdrops());
        document.getElementById('cancelSend').addEventListener('click', () => this.closeSendModal());
        document.getElementById('confirmSend').addEventListener('click', () => this.sendAirdrop());

        // Close modal when clicking outside
        document.getElementById('sendModal').addEventListener('click', (e) => {
            if (e.target.id === 'sendModal') {
                this.closeSendModal();
            }
        });
    }

    async checkRealWalletConnection() {
        try {
            // First check if we can communicate with content script
            const result = await this.sendMessageToContent('checkWallet').catch(error => {
                console.log('Content script not ready, trying background approach:', error);
                return { success: false, error: 'Content script not available' };
            });
            
            if (result.success && result.connected) {
                // Validate network and get real balance
                const balanceResult = await this.sendMessageToContent('getRealBalance', { address: result.address });
                if (balanceResult.success) {
                    this.updateWalletUI(result.address, balanceResult.balance, result.walletName || 'MetaMask');
                } else {
                    this.showNotification('Failed to get balance: ' + balanceResult.error, 'error');
                    this.resetWalletUI();
                }
            } else {
                // If content script communication fails, reset UI
                console.log('Wallet not connected or content script unavailable');
                this.resetWalletUI();
            }
        } catch (error) {
            console.log('Error checking wallet connection:', error);
            this.resetWalletUI();
        }
    }

    async checkWalletStatus() {
        // Always check stored real wallet state
        try {
            const result = await this.sendMessageToBackground('getStoredData', { keys: ['connectedWallet'] });
            if (result.success && result.data.connectedWallet) {
                const walletData = result.data.connectedWallet;
                const balanceResponse = await this.sendMessageToContent('checkWallet');
                if (balanceResponse.success && balanceResponse.connected) {
                    this.updateWalletUI(walletData.address, balanceResponse.balance, walletData.walletName);
                } else {
                    this.resetWalletUI();
                }
            } else {
                this.resetWalletUI();
            }
        } catch (error) {
            console.log('No wallet connection found:', error);
            this.resetWalletUI();
        }
    }

    async connectWallet() {
        // Simpler, reliable flow: run a page-context script to request accounts and token balances
        const connectBtn = document.getElementById('connectBtn');
        connectBtn.textContent = 'Connecting...';
        connectBtn.disabled = true;

        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) throw new Error('No active tab found');

            // Execute a function in the page that interacts with window.ethereum and returns balances
            const execResults = await chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                world: 'MAIN',
                func: async (tokenList) => {
                    try {
                        // Wait briefly for provider injection (MetaMask may inject after load)
                        let provider = window.ethereum || (window.web3 && window.web3.currentProvider);
                        const maxWait = 3000; const interval = 200; let waited = 0;
                        while (!provider && waited < maxWait) {
                            await new Promise(r => setTimeout(r, interval));
                            waited += interval;
                            provider = window.ethereum || (window.web3 && window.web3.currentProvider);
                        }
                        if (!provider) return { success: false, error: 'No Web3 wallet detected on this page. Please allow this site in your wallet and refresh.' };

                        // Request accounts
                        let accounts;
                        if (provider.request) {
                            accounts = await provider.request({ method: 'eth_requestAccounts' });
                        } else if (provider.enable) {
                            accounts = await provider.enable();
                        } else {
                            return { success: false, error: 'Wallet does not support account access' };
                        }

                        if (!accounts || accounts.length === 0) return { success: false, error: 'No accounts returned' };
                        const address = accounts[0];

                        // Get chainId and native balance
                        let chainId = null;
                        try { chainId = await provider.request({ method: 'eth_chainId' }); } catch (e) {}
                        let rawBal = await provider.request({ method: 'eth_getBalance', params: [address, 'latest'] });
                        const nativeBalance = parseInt(rawBal, 16) / Math.pow(10, 18);

                        // Helper for ERC20 balanceOf
                        async function getTokenBalance(tokenAddr) {
                            try {
                                const data = '0x70a08231' + address.slice(2).padStart(64, '0');
                                const res = await provider.request({ method: 'eth_call', params: [{ to: tokenAddr, data }, 'latest'] });
                                return parseInt(res, 16) / Math.pow(10, 18);
                            } catch (e) { return 0; }
                        }

                        const tokenBalances = [];
                        for (const t of tokenList) {
                            const bal = await getTokenBalance(t.address);
                            tokenBalances.push({ address: t.address, symbol: t.symbol, balance: bal });
                        }

                        return { success: true, address, walletName: provider.isMetaMask ? 'MetaMask' : 'Web3 Wallet', chainId, nativeBalance, tokenBalances };
                    } catch (err) {
                        return { success: false, error: err && err.message ? err.message : String(err) };
                    }
                },
                args: [[
                    { address: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82', symbol: 'CAKE' },
                    { address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', symbol: 'BUSD' },
                    { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', symbol: 'USDC' },
                    { address: '0x55d398326f99059fF775485246999027B3197955', symbol: 'USDT' },
                    { address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', symbol: 'BTCB' }
                ]]
            });

            const pageResult = Array.isArray(execResults) && execResults[0] ? execResults[0].result : null;
            if (!pageResult || !pageResult.success) throw new Error((pageResult && pageResult.error) || 'Failed to connect via page provider');

            // Save connected wallet to storage
            await chrome.storage.local.set({ connectedWallet: { address: pageResult.address, walletName: pageResult.walletName } });

            // Update UI
            const balance = pageResult.nativeBalance || 0;
            this.updateWalletUI(pageResult.address, balance, pageResult.walletName);
            this.showNotification('Wallet connected: ' + this.truncateAddress(pageResult.address), 'success');
        } catch (error) {
            console.error('connectWallet error:', error);
            this.showNotification('Failed to connect wallet: ' + (error && error.message ? error.message : String(error)), 'error');
        } finally {
            connectBtn.textContent = 'Connect Wallet';
            connectBtn.disabled = false;
        }
    }

    async disconnectWallet() {
        try {
            const result = await this.sendMessageToBackground('disconnectWallet');
            if (result.success) {
                this.resetWalletUI();
                this.showNotification('Wallet disconnected', 'info');
            } else {
                throw new Error(result.error || 'Failed to disconnect wallet');
            }
        } catch (error) {
            this.showNotification('Failed to disconnect wallet: ' + error.message, 'error');
        }
    }

    updateWalletUI(address, balance, walletName) {
        const statusDot = document.getElementById('statusDot');
        const walletStatus = document.getElementById('walletStatus');
        const walletAddress = document.getElementById('walletAddress');
        const balanceElement = document.getElementById('balance');
        const connectBtn = document.getElementById('connectBtn');
        const scanBtn = document.getElementById('scanBtn');
        const connectedText = document.getElementById('connectedText');

        statusDot.classList.add('connected');
        walletStatus.textContent = `Connected (${walletName})`;
        walletAddress.textContent = this.truncateAddress(address);
        walletAddress.style.display = 'block';
        balanceElement.textContent = `Balance: ${balance.toFixed(4)} BNB`;

        connectBtn.style.display = 'none';
        connectedText.style.display = 'block';
        scanBtn.disabled = false;

        this.wallet = { address, balance, walletName };
    }

    resetWalletUI() {
        const statusDot = document.getElementById('statusDot');
        const walletStatus = document.getElementById('walletStatus');
        const walletAddress = document.getElementById('walletAddress');
        const balanceElement = document.getElementById('balance');
        const connectBtn = document.getElementById('connectBtn');
        const scanBtn = document.getElementById('scanBtn');
        const connectedText = document.getElementById('connectedText');

        statusDot.classList.remove('connected');
        walletStatus.textContent = 'Disconnected';
        walletAddress.style.display = 'none';
        balanceElement.textContent = 'Balance: -- BNB';

        connectBtn.style.display = 'block';
        connectedText.style.display = 'none';
        connectBtn.textContent = 'Connect Wallet';
        connectBtn.onclick = () => this.connectWallet();
        scanBtn.disabled = true;

        this.wallet = null;
        this.clearAirdrops();
    }

    async scanAirdrops() {
        // Always run a fresh page-context scan for token balances (most reliable)
        if (!this.wallet) {
            this.showNotification('Please connect your wallet first', 'error');
            return;
        }

        const content = document.getElementById('airdropContent');
        content.innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <div>Scanning blockchain for airdrops...</div>
            </div>
        `;

        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) throw new Error('No active tab');

            const execResults = await chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                world: 'MAIN',
                func: async (address, tokenList) => {
                    try {
                        // Wait briefly for provider to appear
                        let provider = window.ethereum || (window.web3 && window.web3.currentProvider);
                        const maxWait = 3000; const interval = 200; let waited = 0;
                        while (!provider && waited < maxWait) {
                            await new Promise(r => setTimeout(r, interval));
                            waited += interval;
                            provider = window.ethereum || (window.web3 && window.web3.currentProvider);
                        }
                        if (!provider) return { success: false, error: 'No web3 provider on page. Please allow this site in your wallet.' };

                        async function getTokenBalance(tokenAddr) {
                            try {
                                const data = '0x70a08231' + address.slice(2).padStart(64, '0');
                                const res = await provider.request({ method: 'eth_call', params: [{ to: tokenAddr, data }, 'latest'] });
                                return parseInt(res, 16) / Math.pow(10, 18);
                            } catch (e) { return 0; }
                        }

                        const found = [];
                        for (const t of tokenList) {
                            const bal = await getTokenBalance(t.address);
                            if (bal && bal > 0) {
                                found.push({ id: t.symbol.toLowerCase() + '-balance', name: t.symbol + ' Balance', amount: bal.toFixed(4), symbol: t.symbol, claimable: true, description: 'Detected token balance', apy: 'N/A', category: 'Balance' });
                            }
                        }

                        return { success: true, airdrops: found };
                    } catch (err) { return { success: false, error: err && err.message ? err.message : String(err) }; }
                },
                args: [this.wallet.address, [
                    { address: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82', symbol: 'CAKE' },
                    { address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', symbol: 'BUSD' },
                    { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', symbol: 'USDC' },
                    { address: '0x55d398326f99059fF775485246999027B3197955', symbol: 'USDT' },
                    { address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', symbol: 'BTCB' }
                ]]
            });

            const pageRes = Array.isArray(execResults) && execResults[0] ? execResults[0].result : null;
            if (!pageRes || !pageRes.success) throw new Error(pageRes && pageRes.error ? pageRes.error : 'Scan failed');

            this.rewards = pageRes.airdrops || [];
            this.displayAirdrops();
        } catch (error) {
            console.error('Scan error:', error);
            content.innerHTML = `
                <div class="no-airdrops">
                    Error scanning airdrops: ${error && error.message ? error.message : String(error)}
                </div>
            `;
        }
    }

    displayAirdrops() {
        const content = document.getElementById('airdropContent');
        
        if (this.rewards.length === 0) {
            content.innerHTML = `
                <div class="no-airdrops">
                    No airdrops found for your wallet
                </div>
            `;
            return;
        }

        const rewardHTML = this.rewards.map((reward, index) => `
            <div class="airdrop-item">
                <div class="airdrop-name">
                    ${reward.name}
                    <span style="float: right; font-size: 12px; color: #00d4aa;">${reward.apy}</span>
                </div>
                <div class="airdrop-amount">${reward.amount} ${reward.symbol}</div>
                <div style="font-size: 11px; opacity: 0.8; margin-bottom: 8px;">${reward.description}</div>
                <div class="airdrop-actions">
                    ${reward.claimable ? `<button class="btn-small btn-claim" onclick="dropXPopup.claimAirdrop(${index})">Claim Now</button>` : '<button class="btn-small" style="background: #666; cursor: not-allowed;" disabled>Locked</button>'}
                    <button class="btn-small btn-send" onclick="dropXPopup.openSendModal(${index})">Send</button>
                </div>
            </div>
        `).join('');

            const totalClaimable = this.rewards
            .filter(r => r.claimable)
            .reduce((sum, r) => sum + parseFloat(r.amount), 0);
            
        const bnbPrice = 320.50; // BNB price in USD
        const usdValue = totalClaimable * 0.8; // Approximate USD value for mixed tokens
            
        const summaryHTML = `
            <div style="background: rgba(0, 212, 170, 0.1); padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(0, 212, 170, 0.3);">
                <div style="text-align: center; color: #00d4aa; font-weight: 600;">
                    💰 Total Claimable Value
                </div>
                <div style="text-align: center; font-size: 12px; opacity: 0.8; margin-top: 4px;">
                    ~$${usdValue.toFixed(2)} USD (Mixed BNB Ecosystem Tokens)
                </div>
            </div>
        `;

        content.innerHTML = summaryHTML + `<div class="airdrop-list">${rewardHTML}</div>`;
    }

    async claimAirdrop(index) {
        const reward = this.rewards[index];
        if (!reward || !reward.claimable) return;

        try {
            // Show claiming in progress
            this.showNotification(`Claiming ${reward.amount} ${reward.symbol}...`, 'info');
            
            const result = await this.sendMessageToBackground('claimRealAirdrop', {
                rewardId: reward.id,
                address: this.wallet.address,
                tokenSymbol: reward.symbol,
                amount: reward.amount
            });

            if (result.success) {
                this.showNotification(`Successfully claimed ${reward.amount} ${reward.symbol}! 🎉`, 'success');
                
                // Update UI to show claimed state
                reward.claimable = false;
                this.displayAirdrops();
                
                // Update balance if transaction included gas costs
                if (result.newBalance !== undefined) {
                    this.wallet.balance = result.newBalance;
                    document.getElementById('balance').textContent = `Balance: ${result.newBalance.toFixed(4)} BNB`;
                }
            } else {
                throw new Error(result.error || 'Failed to claim airdrop');
            }
        } catch (error) {
            this.showNotification('Failed to claim: ' + error.message, 'error');
        }
    }

    openSendModal(index) {
        const reward = this.rewards[index];
        if (!reward) return;

        document.getElementById('sendAmount').value = reward.amount;
        document.getElementById('sendAmount').dataset.rewardIndex = index;
        document.getElementById('sendModal').style.display = 'block';
    }

    closeSendModal() {
        document.getElementById('sendModal').style.display = 'none';
        document.getElementById('recipientAddress').value = '';
        document.getElementById('sendAmount').value = '';
    }

    async sendAirdrop() {
        const recipientAddress = document.getElementById('recipientAddress').value.trim();
        const amount = parseFloat(document.getElementById('sendAmount').value);
        const rewardIndex = parseInt(document.getElementById('sendAmount').dataset.rewardIndex);

        if (!recipientAddress) {
            this.showNotification('Please enter recipient address', 'error');
            return;
        }

        if (!amount || amount <= 0) {
            this.showNotification('Please enter valid amount', 'error');
            return;
        }

        try {
            // Proceed with real send flow
            
            const reward = this.rewards[rewardIndex];
            const result = await this.sendMessageToBackground('sendReward', {
                rewardId: reward.id,
                recipientAddress,
                amount,
                address: this.wallet.address,
                tokenAddress: reward.tokenAddress,
            });

            if (result.success) {
                this.showNotification(`Successfully sent ${amount} ${reward.symbol}!`, 'success');
                this.closeSendModal();
                this.wallet.balance = result.newBalance;
                document.getElementById('balance').textContent = `Balance: ${result.newBalance.toFixed(4)} BNB`;
            } else {
                throw new Error(result.error || 'Failed to send tokens');
            }
        } catch (error) {
            this.showNotification('Failed to send: ' + error.message, 'error');
        }
    }

    clearAirdrops() {
        this.rewards = [];
        document.getElementById('airdropContent').innerHTML = `
            <div class="no-airdrops">
                Connect wallet and scan to find available airdrops
            </div>
        `;
    }

    truncateAddress(address) {
        return `${address.slice(0, 4)}...${address.slice(-4)}`;
    }

    async sendMessageToBackground(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action, data }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    async sendMessageToContent(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action, data }, (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(response);
                        }
                    });
                } else {
                    reject(new Error('No active tab found'));
                }
            });
        });
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 12px 16px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
        `;

        switch (type) {
            case 'success':
                notification.style.background = '#2ed573';
                break;
            case 'error':
                notification.style.background = '#ff4757';
                break;
            case 'info':
                notification.style.background = '#3742fa';
                break;
            default:
                notification.style.background = '#747d8c';
        }

        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Real-time price fetching for BNB ecosystem tokens
    async fetchRealBNBPrice() {
        try {
            // Could fetch from CoinGecko API or DEX price feeds
            // Example: const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd');
            // const data = await response.json();
            // return data['binancecoin'].usd;
            return 320.50; // Current BNB market price as fallback
        } catch (error) {
            console.error('Failed to fetch BNB price:', error);
            return 320.50; // Fallback to last known price
        }
    }
}

const dropXPopup = new DropXPopup();