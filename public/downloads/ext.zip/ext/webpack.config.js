const path = require('path');

const mainConfig = {
    entry: {
        content: './content.js',
        background: './background.js',
        popup: './popup.js',
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: '[name].js',
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: { presets: ['@babel/preset-env'] },
                },
            },
        ],
    },
};

const injectedConfig = {
    entry: { injected: './injected.js' },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'injected.js',
        library: 'ClaimXInjected',
        libraryTarget: 'var',
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: { presets: ['@babel/preset-env'] },
                },
            },
        ],
    },
};

module.exports = [mainConfig, injectedConfig];
