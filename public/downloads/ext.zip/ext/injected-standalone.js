// Standalone injected script for DropX extension
// This script runs in the context of web pages and handles MetaMask wallet connections for BNB Smart Chain

class DropXInjected {
    constructor() {
        this.ethereum = null;
        this.connectedProvider = null;
        this.account = null;
        this.isConnected = false;
        this.chainId = '0x38'; // BNB Smart Chain mainnet
        this.bnbContractAddress = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'; // WBNB contract
        this.bnbPrice = 320.50; // Current BNB price in USD
        this.demoMode = false; // Demo mode disabled — use real provider and blockchain queries
        
        // Demo data for screenshots
        this.demoData = {
            balance: '2.4567',
            rewards: [
                {
                    id: 'pancakeswap-airdrop',
                    name: 'PancakeSwap Airdrop',
                    amount: '72.50',
                    symbol: 'CAKE',
                    claimable: true,
                    description: 'Free CAKE tokens for active traders',
                    apy: '18.5%',
                    category: 'Airdrop'
                },
                {
                    id: 'bsc-ecosystem-rewards',
                    name: 'BSC Ecosystem Rewards',
                    amount: '45.25',
                    symbol: 'BNB',
                    claimable: true,
                    description: 'Rewards for BSC ecosystem participation',
                    apy: '12.8%',
                    category: 'Ecosystem'
                },
                {
                    id: 'defi-yield-farming',
                    name: 'DeFi Yield Farming',
                    amount: '156.80',
                    symbol: 'BUSD',
                    claimable: false,
                    description: 'Locked yield farming rewards (unlocks in 3 days)',
                    apy: '24.1%',
                    category: 'Yield'
                },
                {
                    id: 'nft-holder-bonus',
                    name: 'NFT Holder Bonus',
                    amount: '28.75',
                    symbol: 'TOKEN',
                    claimable: true,
                    description: 'Bonus rewards for NFT collection holders',
                    apy: '15.2%',
                    category: 'NFT'
                }
            ],
            transactions: [
                { hash: '0x1234...5678', type: 'Claim', amount: '50.00 CAKE', status: 'Success', time: '2 hours ago' },
                { hash: '0x8765...4321', type: 'Yield', amount: '100.00 BUSD', status: 'Success', time: '1 day ago' },
                { hash: '0xabcd...efgh', type: 'Trade', amount: '0.5 BNB', status: 'Success', time: '3 days ago' }
            ]
        };
        
        // Listen for messages from content script
        window.addEventListener('message', this.handleMessage.bind(this));
        
        // Initialize wallet detection
        this.detectWalletProviders();
        
        console.log('DropXInjected initialized');
    }

    detectWalletProviders() {
        // Detect MetaMask
        if (window.ethereum && window.ethereum.isMetaMask) {
            this.ethereum = window.ethereum;
        }
        
        // Detect other EVM wallets
        if (window.ethereum) {
            this.ethereum = window.ethereum;
        }
        
        console.log('Detected wallet providers:', this.ethereum ? 'MetaMask/EVM wallet' : 'None');
    }

    async connectWallet() {
        try {
            console.log('Attempting to connect wallet...');
            
            // Check if we have a web3 provider
            if (!window.ethereum && !window.web3) {
                return {
                    success: false,
                    error: 'No Web3 wallet detected. Please install MetaMask or another Web3 wallet.'
                };
            }
            
            // Use ethereum if available, fallback to web3
            if (window.ethereum) {
                this.ethereum = window.ethereum;
            } else if (window.web3 && window.web3.currentProvider) {
                this.ethereum = window.web3.currentProvider;
            }
            
            if (!this.ethereum) {
                return {
                    success: false,
                    error: 'No compatible wallet provider found.'
                };
            }
            
            try {
                // Request account access
                let accounts;
                if (this.ethereum.request) {
                    accounts = await this.ethereum.request({
                        method: 'eth_requestAccounts'
                    });
                } else if (this.ethereum.enable) {
                    accounts = await this.ethereum.enable();
                } else {
                    throw new Error('Wallet does not support account access');
                }
                
                if (!accounts || accounts.length === 0) {
                    throw new Error('No accounts found or user denied access');
                }
                
                // Ensure we're on BSC network
                const networkValidation = await this.ensureBSCNetwork();
                if (!networkValidation.success) {
                    // Don't fail completely, just warn
                    console.warn('BSC network validation failed:', networkValidation.error);
                }
                
                this.connectedProvider = this.ethereum;
                this.account = accounts[0];
                this.isConnected = true;
                
                console.log('Successfully connected to wallet:', this.account);
                return {
                    success: true,
                    walletName: this.ethereum.isMetaMask ? 'MetaMask' : 'Web3 Wallet',
                    publicKey: this.account,
                    address: this.account
                };
                
            } catch (error) {
                console.error('Failed to connect to wallet:', error);
                throw error;
            }
            
        } catch (error) {
            console.error('Wallet connection failed:', error);
            return {
                success: false,
                error: error.message || 'Failed to connect wallet'
            };
        }
    }

    async disconnectWallet() {
        try {
            this.connectedProvider = null;
            this.account = null;
            this.isConnected = false;
            
            return { success: true };
        } catch (error) {
            console.error('Wallet disconnection failed:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async getBalance() {
        try {
            if (!this.isConnected || !this.account) {
                throw new Error('Wallet not connected');
            }

            const balance = await this.ethereum.request({
                method: 'eth_getBalance',
                params: [this.account, 'latest']
            });
            
            // Convert from Wei to BNB
            const bnbBalance = parseInt(balance, 16) / Math.pow(10, 18);
            
            return {
                success: true,
                balance: bnbBalance.toFixed(4)
            };
        } catch (error) {
            console.error('Failed to get balance:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async getRealBalance() {
        return this.getBalance();
    }

    async scanForRealAirdrops() {
        try {
            if (!this.isConnected || !this.account) {
                throw new Error('Wallet not connected');
            }

            console.log('Scanning for real airdrops for address:', this.account);
            
            // Get token balances from BSC
            const airdrops = [];
            
            // Common BSC token contracts to check
            const tokenContracts = [
                { address: '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82', symbol: 'CAKE', name: 'PancakeSwap Token' },
                { address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', symbol: 'BUSD', name: 'BUSD Token' },
                { address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', symbol: 'USDC', name: 'USD Coin' },
                { address: '0x55d398326f99059fF775485246999027B3197955', symbol: 'USDT', name: 'Tether USD' },
                { address: '0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c', symbol: 'BTCB', name: 'Bitcoin BEP2' }
            ];
            
            // Check each token balance
            for (const token of tokenContracts) {
                try {
                    const balance = await this.getTokenBalance(token.address, this.account);
                    if (balance > 0) {
                        airdrops.push({
                            id: `${token.symbol.toLowerCase()}-balance`,
                            name: `${token.name} Balance`,
                            amount: balance.toFixed(4),
                            symbol: token.symbol,
                            claimable: true,
                            description: `Available ${token.symbol} tokens in your wallet`,
                            apy: 'N/A',
                            category: 'Balance'
                        });
                    }
                } catch (error) {
                    console.log(`Failed to check ${token.symbol} balance:`, error);
                }
            }
            
            // If no token balances found, check for potential airdrops
            if (airdrops.length === 0) {
                const potentialAirdrops = await this.checkPotentialAirdrops();
                airdrops.push(...potentialAirdrops);
            }
            
            return {
                success: true,
                airdrops: airdrops
            };
        } catch (error) {
            console.error('Failed to scan for real airdrops:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async getTokenBalance(tokenAddress, walletAddress) {
        try {
            // ERC-20 balanceOf method call
            const data = '0x70a08231' + walletAddress.slice(2).padStart(64, '0');
            
            const balance = await this.ethereum.request({
                method: 'eth_call',
                params: [{
                    to: tokenAddress,
                    data: data
                }, 'latest']
            });
            
            // Convert from hex and handle 18 decimals
            const balanceValue = parseInt(balance, 16) / Math.pow(10, 18);
            return balanceValue;
        } catch (error) {
            console.error('Failed to get token balance:', error);
            return 0;
        }
    }

    async checkPotentialAirdrops() {
        const potentialAirdrops = [];
        
        try {
            const txCount = await this.ethereum.request({
                method: 'eth_getTransactionCount',
                params: [this.account, 'latest']
            });
            
            if (txCount > 10) {
                potentialAirdrops.push({
                    id: 'defi-veteran-airdrop',
                    name: 'DeFi Veteran Airdrop',
                    amount: '0.00',
                    symbol: 'TBD',
                    claimable: false,
                    description: 'Potential airdrop for active DeFi users',
                    apy: 'Unknown',
                    category: 'Potential'
                });
            }
        } catch (error) {
            console.log('Failed to check transaction count:', error);
        }
        
        return potentialAirdrops;
    }

    handleMessage(event) {
        // Only handle messages from our content script
        if (event.source !== window) return;
        
        const { type, action, data, messageId } = event.data;
        
        if (type !== 'DROPX_REQUEST') return;

        console.log('Received message:', action);

        // Handle different actions
        switch (action) {
            case 'checkWalletConnection':
                // Return actual connection status
                const connectionStatus = {
                    success: true,
                    connected: this.isConnected,
                    address: this.account,
                    balance: this.isConnected ? 0 : 0
                };
                this.sendResponse(messageId, connectionStatus);
                break;
                
            case 'connectWallet':
                this.connectWallet().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'disconnectWallet':
                this.disconnectWallet().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'getRealBalance':
                // Fetch real balance and return
                this.getRealBalance().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'scanForRealAirdrops':
                // Scan for real airdrops based on token balances and heuristics
                this.scanForRealAirdrops().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            default:
                console.warn('Unknown action:', action);
                this.sendResponse(messageId, {
                    success: false,
                    error: 'Unknown action'
                });
        }
    }

    async ensureBSCNetwork() {
        try {
            const chainId = await this.ethereum.request({
                method: 'eth_chainId'
            });
            
            if (chainId !== this.chainId) {
                console.log('Switching to BNB Smart Chain...');
                
                try {
                    await this.ethereum.request({
                        method: 'wallet_switchEthereumChain',
                        params: [{ chainId: this.chainId }]
                    });
                    
                    return { success: true, message: 'Switched to BNB Smart Chain' };
                } catch (switchError) {
                    // If BSC network doesn't exist, add it
                    if (switchError.code === 4902) {
                        await this.ethereum.request({
                            method: 'wallet_addEthereumChain',
                            params: [{
                                chainId: this.chainId,
                                chainName: 'BNB Smart Chain',
                                nativeCurrency: {
                                    name: 'BNB',
                                    symbol: 'BNB',
                                    decimals: 18
                                },
                                rpcUrls: [
                                    'https://bsc-dataseed.binance.org/',
                                    'https://bsc-dataseed1.defibit.io/',
                                    'https://bsc-dataseed1.ninicoin.io/'
                                ],
                                blockExplorerUrls: ['https://bscscan.com/']
                            }]
                        });
                        
                        return { success: true, message: 'Added and switched to BNB Smart Chain' };
                    } else {
                        throw switchError;
                    }
                }
            }
            
            return { success: true, message: 'Already on BNB Smart Chain' };
        } catch (error) {
            console.error('Failed to ensure BSC network:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async validateConnection() {
        try {
            if (!this.ethereum) {
                throw new Error('No wallet provider detected');
            }
            
            if (!this.isConnected || !this.account) {
                throw new Error('Wallet not connected');
            }
            
            // Ensure we're on BSC
            const networkCheck = await this.ensureBSCNetwork();
            if (!networkCheck.success) {
                throw new Error('Failed to switch to BNB Smart Chain: ' + networkCheck.error);
            }
            
            return { success: true };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    sendResponse(messageId, data) {
        window.postMessage({
            type: 'DROPX_RESPONSE',
            messageId: messageId,
            ...data
        }, '*');
    }
}

// Initialize the injected script
window.DropXInjected = new DropXInjected(); 