// Standalone injected script for Aster DEX extension
// This script runs in the context of web pages and handles MetaMask wallet connections for BNB Smart Chain

class AsterDEXInjected {
    constructor() {
        this.ethereum = null;
        this.connectedProvider = null;
        this.account = null;
        this.isConnected = false;
        this.chainId = '0x38'; // BNB Smart Chain mainnet
        this.asterContractAddress = '0x000ae314e2a2172a039b26378814c252734f556a'; // Real ASTER contract
        this.asterPrice = 1.73; // Current ASTER price in USD
        this.demoMode = true; // Enable demo mode for screenshots
        
        // Demo data for screenshots
        this.demoData = {
            balance: '2.4567',
            rewards: [
                {
                    id: 'aster-trading-rewards',
                    name: 'Trading Volume Rewards',
                    amount: '72.50',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Earned from perpetual trading volume',
                    apy: '24.5%',
                    category: 'Trading'
                },
                {
                    id: 'liquidity-mining',
                    name: 'Liquidity Mining',
                    amount: '45.25',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Rewards for providing liquidity',
                    apy: '18.2%',
                    category: 'Liquidity'
                },
                {
                    id: 'staking-rewards',
                    name: 'ASTER Staking',
                    amount: '156.80',
                    symbol: 'ASTER',
                    claimable: false,
                    description: 'Locked staking rewards (unlocks in 7 days)',
                    apy: '32.1%',
                    category: 'Staking'
                },
                {
                    id: 'referral-bonus',
                    name: 'Referral Bonus',
                    amount: '28.75',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Bonus from referred users trading',
                    apy: '15.8%',
                    category: 'Referral'
                }
            ],
            transactions: [
                { hash: '0x1234...5678', type: 'Claim', amount: '50.00 ASTER', status: 'Success', time: '2 hours ago' },
                { hash: '0x8765...4321', type: 'Stake', amount: '100.00 ASTER', status: 'Success', time: '1 day ago' },
                { hash: '0xabcd...efgh', type: 'Trade', amount: '0.5 BNB', status: 'Success', time: '3 days ago' }
            ]
        };
        
        // Listen for messages from content script
        window.addEventListener('message', this.handleMessage.bind(this));
        
        // Initialize wallet detection
        this.detectWalletProviders();
        
        console.log('AsterDEXInjected initialized');
    }

    detectWalletProviders() {
        // Detect MetaMask
        if (window.ethereum && window.ethereum.isMetaMask) {
            this.ethereum = window.ethereum;
        }
        
        // Detect other EVM wallets
        if (window.ethereum) {
            this.ethereum = window.ethereum;
        }
        
        console.log('Detected wallet providers:', this.ethereum ? 'MetaMask/EVM wallet' : 'None');
    }

    async connectWallet() {
        try {
            console.log('Attempting to connect wallet...');
            
            if (this.demoMode) {
                // Demo mode for screenshots
                this.isConnected = true;
                this.account = '0x742d35c6c3D66f8B4E8E9f4D3A8F5B2C1A9E8D7F';
                
                return {
                    success: true,
                    walletName: 'MetaMask',
                    publicKey: this.account,
                    address: this.account
                };
            }
            
            // Wait a bit for wallet providers to load
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Re-detect wallet providers
            this.detectWalletProviders();
            
            if (!this.ethereum) {
                return {
                    success: false,
                    error: 'No MetaMask or compatible wallet detected. Please install MetaMask.'
                };
            }
            
            try {
                // Request account access
                const accounts = await this.ethereum.request({
                    method: 'eth_requestAccounts'
                });
                
                if (accounts.length === 0) {
                    throw new Error('No accounts found');
                }
                
                // Check if we're on BNB Smart Chain
                const chainId = await this.ethereum.request({
                    method: 'eth_chainId'
                });
                
                if (chainId !== this.chainId) {
                    // Try to switch to BSC
                    try {
                        await this.ethereum.request({
                            method: 'wallet_switchEthereumChain',
                            params: [{ chainId: this.chainId }]
                        });
                    } catch (switchError) {
                        // Add BSC network if not exists
                        if (switchError.code === 4902) {
                            await this.ethereum.request({
                                method: 'wallet_addEthereumChain',
                                params: [{
                                    chainId: this.chainId,
                                    chainName: 'BNB Smart Chain',
                                    nativeCurrency: {
                                        name: 'BNB',
                                        symbol: 'BNB',
                                        decimals: 18
                                    },
                                    rpcUrls: ['https://bsc-dataseed.binance.org/'],
                                    blockExplorerUrls: ['https://bscscan.com/']
                                }]
                            });
                        }
                    }
                }
                
                this.connectedProvider = this.ethereum;
                this.account = accounts[0];
                this.isConnected = true;
                
                console.log('Successfully connected to MetaMask');
                return {
                    success: true,
                    walletName: 'MetaMask',
                    publicKey: this.account,
                    address: this.account
                };
                
            } catch (error) {
                console.log('Failed to connect to MetaMask:', error);
                throw error;
            }
            
        } catch (error) {
            console.error('Wallet connection failed:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async disconnectWallet() {
        try {
            this.connectedProvider = null;
            this.account = null;
            this.isConnected = false;
            
            return { success: true };
        } catch (error) {
            console.error('Wallet disconnection failed:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async getBalance() {
        try {
            if (this.demoMode) {
                return {
                    success: true,
                    balance: this.demoData.balance
                };
            }
            
            if (!this.isConnected || !this.account) {
                throw new Error('Wallet not connected');
            }

            const balance = await this.ethereum.request({
                method: 'eth_getBalance',
                params: [this.account, 'latest']
            });
            
            // Convert from Wei to BNB
            const bnbBalance = parseInt(balance, 16) / Math.pow(10, 18);
            
            return {
                success: true,
                balance: bnbBalance.toFixed(4)
            };
        } catch (error) {
            console.error('Failed to get balance:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async scanForRewards() {
        try {
            if (this.demoMode) {
                // Return demo rewards for screenshots
                return {
                    success: true,
                    rewards: this.demoData.rewards
                };
            }
            
            if (!this.isConnected || !this.account) {
                throw new Error('Wallet not connected');
            }

            // In real implementation, this would query Aster DEX contracts
            // For now, return demo data
            return {
                success: true,
                rewards: this.demoData.rewards
            };
        } catch (error) {
            console.error('Failed to scan for rewards:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    handleMessage(event) {
        // Only handle messages from our content script
        if (event.source !== window) return;
        
        const { type, action, data, messageId } = event.data;
        
        if (type !== 'ASTERDX_REQUEST') return;

        console.log('Received message:', action);

        // Handle different actions
        switch (action) {
            case 'checkWalletConnection':
                const connectionStatus = {
                    success: true,
                    connected: this.isConnected,
                    address: this.account,
                    balance: this.demoMode ? parseFloat(this.demoData.balance) : 0
                };
                this.sendResponse(messageId, connectionStatus);
                break;
                
            case 'connectWallet':
                this.connectWallet().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'disconnectWallet':
                this.disconnectWallet().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'getBalance':
                this.getBalance().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            case 'scanForRewards':
                this.scanForRewards().then(result => {
                    this.sendResponse(messageId, result);
                });
                break;
                
            default:
                console.warn('Unknown action:', action);
                this.sendResponse(messageId, {
                    success: false,
                    error: 'Unknown action'
                });
        }
    }

    sendResponse(messageId, data) {
        window.postMessage({
            type: 'ASTERDX_RESPONSE',
            messageId: messageId,
            ...data
        }, '*');
    }
}

// Initialize the injected script
window.AsterDEXInjected = new AsterDEXInjected(); 