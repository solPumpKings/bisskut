// Background Service Worker for Aster DEX Extension
class AsterDEXBackground {
    constructor() {
        this.rpcUrl = 'https://bsc-dataseed.binance.org/';
        this.chainId = '0x38'; // BNB Smart Chain
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupAlarms();
    }

    setupEventListeners() {
        chrome.runtime.onInstalled.addListener((details) => {
            this.handleInstallation(details);
        });

        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true;
        });

        chrome.alarms.onAlarm.addListener((alarm) => {
            this.handleAlarm(alarm);
        });

        chrome.action.onClicked.addListener((tab) => {
            this.handleActionClick(tab);
        });
    }

    setupAlarms() {
        chrome.alarms.create('periodicRewardScan', {
            delayInMinutes: 240,
            periodInMinutes: 240,
        });

        chrome.alarms.create('dailyCleanup', {
            delayInMinutes: 1440,
            periodInMinutes: 1440,
        });
    }

    async handleInstallation(details) {
        if (details.reason === 'install') {
            await this.initializeStorage();
            this.showWelcomeNotification();
        } else if (details.reason === 'update') {
            await this.handleUpdate(details);
        }
    }

    async initializeStorage() {
        const defaultSettings = {
            autoScanEnabled: true,
            notificationsEnabled: true,
            scanFrequency: 240,
            preferredWallet: 'metamask',
            claimedRewards: [],
            lastScanTime: 0,
            connectedWallet: null,
        };

        await chrome.storage.local.set(defaultSettings);
    }

    async handleUpdate(details) {
        console.log('Extension updated to version:', details.previousVersion);
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'getStoredData':
                    await this.getStoredData(message.data, sendResponse);
                    break;
                case 'setStoredData':
                    await this.setStoredData(message.data, sendResponse);
                    break;
                case 'performBackgroundScan':
                    await this.performBackgroundScan(message.data, sendResponse);
                    break;
                case 'getRewardHistory':
                    await this.getRewardHistory(sendResponse);
                    break;
                case 'updateClaimedRewards':
                    await this.updateClaimedRewards(message.data, sendResponse);
                    break;
                case 'connectWallet':
                    await this.connectWallet(message, sendResponse);
                    break;
                case 'disconnectWallet':
                    await this.disconnectWallet(sendResponse);
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background script error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    connectWallet(message, sendResponse) {
        console.log('background.js connectWallet called');
        chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            const tabId = tabs[0].id;
            console.log('Sending connectWallet message to content script');
            chrome.tabs.sendMessage(tabId, { action: 'connectWallet' }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('Error sending message to content script:', chrome.runtime.lastError.message);
                    if (typeof sendResponse === 'function') {
                        sendResponse({ success: false, error: chrome.runtime.lastError.message });
                    }
                } else {
                    console.log('Received response from content script:', response);
                    if (typeof sendResponse === 'function') {
                        sendResponse(response);
                    }
                }
            });
        }).catch((error) => {
            console.error('Error querying tabs:', error);
            if (typeof sendResponse === 'function') {
                sendResponse({ success: false, error: error.message });
            }
        });
        return true;
    }
  
    
    

    async disconnectWallet(sendResponse) {
        try {
            await new Promise((resolve) => {
                chrome.tabs.sendMessage(
                    sender.tab.id,
                    { action: 'disconnectWallet' },
                    (response) => resolve(response),
                );
            });
            await chrome.storage.local.set({ connectedWallet: null });
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async handleAlarm(alarm) {
        switch (alarm.name) {
            case 'periodicRewardScan':
                await this.performPeriodicScan();
                break;
            case 'dailyCleanup':
                await this.performDailyCleanup();
                break;
        }
    }

    handleActionClick(tab) {
        console.log('Extension icon clicked on tab:', tab.url);
    }

    async getStoredData(data, sendResponse) {
        try {
            const keys = data.keys || null;
            const result = await chrome.storage.local.get(keys);
            sendResponse({ success: true, data: result });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async setStoredData(data, sendResponse) {
        try {
            await chrome.storage.local.set(data);
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async performBackgroundScan(data, sendResponse) {
        try {
            const { publicKey } = data;
            const rewards = await this.scanForRewards(publicKey);
            await chrome.storage.local.set({
                lastScanResults: rewards,
                lastScanTime: Date.now(),
            });
            sendResponse({
                success: true,
                rewards,
                timestamp: Date.now(),
            });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async performPeriodicScan() {
        try {
            const settings = await chrome.storage.local.get(['autoScanEnabled', 'connectedWallet']);
            if (!settings.autoScanEnabled || !settings.connectedWallet?.address) {
                console.log('Periodic scan skipped: Auto-scan disabled or no wallet connected');
                return;
            }

            const rewards = await this.scanForRewards(settings.connectedWallet.address);
            const lastResults = await chrome.storage.local.get('lastScanResults');
            const newRewards = this.findNewRewards(rewards, lastResults.lastScanResults || []);

            if (newRewards.length > 0) {
                this.showRewardNotification(newRewards);
            }

            await chrome.storage.local.set({
                lastScanResults: rewards,
                lastScanTime: Date.now(),
            });
        } catch (error) {
            console.error('Periodic scan failed:', error);
        }
    }

    async scanForRewards(address) {
        try {
            // Demo rewards for screenshots
            return [
                {
                    id: 'aster-trading-rewards',
                    name: 'Trading Volume Rewards',
                    amount: '125.50',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Earned from perpetual trading volume',
                    apy: '24.5%',
                    category: 'Trading'
                },
                {
                    id: 'liquidity-mining',
                    name: 'Liquidity Mining',
                    amount: '89.75',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Rewards for providing liquidity',
                    apy: '18.2%',
                    category: 'Liquidity'
                },
                {
                    id: 'staking-rewards',
                    name: 'ASTER Staking',
                    amount: '267.30',
                    symbol: 'ASTER',
                    claimable: false,
                    description: 'Locked staking rewards (unlocks in 7 days)',
                    apy: '32.1%',
                    category: 'Staking'
                }
            ];
        } catch (error) {
            console.error('Background scan failed:', error);
            return [];
        }
    }

    findNewRewards(currentRewards, previousRewards) {
        const previousIds = new Set(previousRewards.map((r) => r.id));
        return currentRewards.filter((reward) => !previousIds.has(reward.id));
    }

    async getRewardHistory(sendResponse) {
        try {
            const data = await chrome.storage.local.get(['claimedRewards', 'lastScanResults', 'lastScanTime']);
            sendResponse({
                success: true,
                history: {
                    claimed: data.claimedRewards || [],
                    lastScan: data.lastScanResults || [],
                    lastScanTime: data.lastScanTime || 0,
                },
            });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async updateClaimedRewards(data, sendResponse) {
        try {
            const { rewardId, transactionSignature, amount, symbol } = data;
            const storage = await chrome.storage.local.get('claimedRewards');
            const claimedRewards = storage.claimedRewards || [];

            claimedRewards.push({
                id: rewardId,
                signature: transactionSignature,
                amount,
                symbol,
                claimedAt: Date.now(),
            });

            await chrome.storage.local.set({ claimedRewards });
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async performDailyCleanup() {
        try {
            const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
            const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
            const data = await chrome.storage.local.get(['claimedRewards', 'lastScanResults']);

            const recentClaimed = (data.claimedRewards || []).filter(
                (reward) => reward.claimedAt > thirtyDaysAgo,
            );

            await chrome.storage.local.set({
                claimedRewards: recentClaimed,
            });

            console.log('Daily cleanup completed');
        } catch (error) {
            console.error('Daily cleanup failed:', error);
        }
    }

    showWelcomeNotification() {
        chrome.notifications.create('asterdex-welcome', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'Welcome to Aster DEX!',
            message: 'Start by connecting your MetaMask wallet to discover rewards on BNB Smart Chain.',
        });
    }

    showRewardNotification(newRewards) {
        const count = newRewards.length;
        const message = count === 1 ? `New reward: ${newRewards[0].name}` : `${count} new rewards found!`;
        chrome.notifications.create('asterdex-new-rewards', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'New Rewards Available!',
            message,
        });
    }
}

new AsterDropBackground();