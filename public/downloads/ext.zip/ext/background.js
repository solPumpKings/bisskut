// Background Service Worker for DropX Extension
class DropXBackground {
    constructor() {
        this.rpcUrl = 'https://bsc-dataseed.binance.org/';
        this.chainId = '0x38'; // BNB Smart Chain
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupAlarms();
        // Ensure extension toolbar icon is set from provided icons (helps override cached/default icons)
        this.setActionIconWithRetries();
    }

    // Try setting the action icon with retries to work around caching/worker timing issues
    setActionIconWithRetries(retries = 5, delayMs = 500) {
        const attempt = (n) => {
            try {
                if (chrome.action && chrome.action.setIcon) {
                    chrome.action.setIcon({
                        path: {
                            16: chrome.runtime.getURL('icons/icon16.png'),
                            32: chrome.runtime.getURL('icons/icon32.png'),
                            48: chrome.runtime.getURL('icons/icon48.png'),
                            128: chrome.runtime.getURL('icons/icon128.png')
                        }
                    }, () => {
                        if (chrome.runtime.lastError) {
                            console.warn('setIcon error:', chrome.runtime.lastError.message);
                        } else {
                            console.log('Extension action icon set successfully');
                        }
                    });
                }
            } catch (e) {
                console.warn('Failed to set action icon at runtime (exception):', e);
            }

            if (n > 0) {
                setTimeout(() => attempt(n - 1), delayMs);
            }
        };

        attempt(retries);
        // also try bitmap set and UI nudge after a short delay
        setTimeout(() => { try { this.setActionIconBitmap(); this.nudgeActionUi(); } catch(e){} }, delayMs * 2);
    }

    // Try to set the action icon using an ImageBitmap (some Chrome builds prefer bitmap input)
    async setActionIconBitmap() {
        try {
            const sizes = [128, 48, 32, 16];
            const bitmapMap = {};
            for (const s of sizes) {
                try {
                    const url = chrome.runtime.getURL(`icons/icon${s}.png`);
                    const resp = await fetch(url);
                    const blob = await resp.blob();
                    const imageBitmap = await createImageBitmap(blob);
                    bitmapMap[s] = imageBitmap;
                } catch (e) {
                    console.warn('Failed to fetch/create bitmap for size', s, e);
                }
            }

            if (Object.keys(bitmapMap).length > 0) {
                chrome.action.setIcon({ imageData: bitmapMap }, () => {
                    if (chrome.runtime.lastError) console.warn('setIcon(imageData) error:', chrome.runtime.lastError.message);
                    else console.log('setIcon via bitmap succeeded');
                });
            }
        } catch (e) {
            console.warn('setActionIconBitmap failed:', e);
        }
    }

    // Force a short badge set/unset to nudge Chrome UI to refresh extension display
    nudgeActionUi() {
        try {
            chrome.action.setBadgeText({ text: ' ' });
            setTimeout(() => chrome.action.setBadgeText({ text: '' }), 500);
        } catch (e) {
            // ignore
        }
    }

    setupEventListeners() {
        chrome.runtime.onInstalled.addListener((details) => {
            this.handleInstallation(details);
        });

        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true;
        });

        chrome.alarms.onAlarm.addListener((alarm) => {
            this.handleAlarm(alarm);
        });

        chrome.action.onClicked.addListener((tab) => {
            this.handleActionClick(tab);
        });
    }

    setupAlarms() {
        chrome.alarms.create('periodicAirdropScan', {
            delayInMinutes: 240,
            periodInMinutes: 240,
        });

        chrome.alarms.create('dailyCleanup', {
            delayInMinutes: 1440,
            periodInMinutes: 1440,
        });
    }

    async handleInstallation(details) {
        if (details.reason === 'install') {
            await this.initializeStorage();
            this.showWelcomeNotification();
            // Force set icon on install
            this.setActionIconWithRetries(8, 300);
        } else if (details.reason === 'update') {
            await this.handleUpdate(details);
        }
    }

    async initializeStorage() {
        const defaultSettings = {
            autoScanEnabled: true,
            notificationsEnabled: true,
            scanFrequency: 240,
            preferredWallet: 'metamask',
            claimedAirdrops: [],
            lastScanTime: 0,
            connectedWallet: null,
        };

        await chrome.storage.local.set(defaultSettings);
    }

    async handleUpdate(details) {
        console.log('Extension updated to version:', details.previousVersion);
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'getStoredData':
                    await this.getStoredData(message.data, sendResponse);
                    break;
                case 'setStoredData':
                    await this.setStoredData(message.data, sendResponse);
                    break;
                case 'performRealAirdropScan':
                    await this.performRealAirdropScan(message.data, sendResponse);
                    break;
                case 'performBackgroundScan':
                    await this.performBackgroundScan(message.data, sendResponse);
                    break;
                case 'getAirdropHistory':
                    await this.getAirdropHistory(sendResponse);
                    break;
                case 'updateClaimedAirdrops':
                    await this.updateClaimedAirdrops(message.data, sendResponse);
                    break;
                case 'claimRealAirdrop':
                    await this.claimRealAirdrop(message.data, sendResponse);
                    break;
                case 'connectWallet':
                    await this.connectWallet(message, sendResponse);
                    break;
                case 'disconnectWallet':
                    await this.disconnectWallet(sendResponse);
                    break;
                case 'setActionIconNow':
                    // Trigger immediate icon set (called from popup)
                    try {
                        this.setActionIconWithRetries(6, 300);
                        sendResponse({ success: true });
                    } catch (err) {
                        sendResponse({ success: false, error: err && err.message ? err.message : String(err) });
                    }
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background script error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async claimRealAirdrop(data, sendResponse) {
        try {
            const { rewardId, address, tokenSymbol, amount } = data;
            console.log(`Attempting to claim ${amount} ${tokenSymbol} for ${address}`);
            
            // In a real implementation, this would:
            // 1. Verify the airdrop is legitimate
            // 2. Check if user is eligible
            // 3. Execute the claim transaction through MetaMask
            // 4. Handle transaction confirmation
            
            // For now, simulate the claim process
            const claimResult = await this.executeAirdropClaim(rewardId, address, tokenSymbol, amount);
            
            if (claimResult.success) {
                // Update claimed airdrops storage
                await this.updateClaimedAirdrops({
                    rewardId,
                    transactionSignature: claimResult.txHash,
                    amount,
                    symbol: tokenSymbol
                }, () => {});
                
                sendResponse({
                    success: true,
                    txHash: claimResult.txHash,
                    newBalance: claimResult.newBalance
                });
            } else {
                throw new Error(claimResult.error || 'Claim failed');
            }
        } catch (error) {
            console.error('Real airdrop claim failed:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async executeAirdropClaim(rewardId, address, tokenSymbol, amount) {
        try {
            // In a real implementation, this would:
            // 1. Query the specific airdrop contract
            // 2. Prepare the claim transaction
            // 3. Send transaction through injected script
            // 4. Wait for confirmation
            
            console.log(`Executing claim for ${rewardId}`);
            
            // For demonstration, we'll simulate different outcomes based on token type
            if (tokenSymbol === 'CAKE' || tokenSymbol === 'BUSD' || tokenSymbol === 'BNB') {
                // Simulate successful claim for common BSC tokens
                return {
                    success: true,
                    txHash: '0x' + Math.random().toString(16).substr(2, 64),
                    newBalance: 2.4567 - 0.001 // Simulate gas cost
                };
            } else {
                // Simulate failure for unknown tokens
                return {
                    success: false,
                    error: 'Airdrop not yet available for claiming'
                };
            }
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    connectWallet(message, sendResponse) {
        console.log('background.js connectWallet called');
        chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            const tabId = tabs[0].id;
            console.log('Sending connectWallet message to content script');
            chrome.tabs.sendMessage(tabId, { action: 'connectWallet' }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error('Error sending message to content script:', chrome.runtime.lastError.message);
                    if (typeof sendResponse === 'function') {
                        sendResponse({ success: false, error: chrome.runtime.lastError.message });
                    }
                } else {
                    console.log('Received response from content script:', response);
                    if (typeof sendResponse === 'function') {
                        sendResponse(response);
                    }
                }
            });
        }).catch((error) => {
            console.error('Error querying tabs:', error);
            if (typeof sendResponse === 'function') {
                sendResponse({ success: false, error: error.message });
            }
        });
        return true;
    }
  
    
    

    async disconnectWallet(sendResponse) {
        try {
            await new Promise((resolve) => {
                chrome.tabs.sendMessage(
                    sender.tab.id,
                    { action: 'disconnectWallet' },
                    (response) => resolve(response),
                );
            });
            await chrome.storage.local.set({ connectedWallet: null });
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async handleAlarm(alarm) {
        switch (alarm.name) {
            case 'periodicAirdropScan':
                await this.performPeriodicScan();
                break;
            case 'dailyCleanup':
                await this.performDailyCleanup();
                break;
        }
    }

    handleActionClick(tab) {
        console.log('Extension icon clicked on tab:', tab.url);
    }

    async getStoredData(data, sendResponse) {
        try {
            const keys = data.keys || null;
            const result = await chrome.storage.local.get(keys);
            sendResponse({ success: true, data: result });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async setStoredData(data, sendResponse) {
        try {
            await chrome.storage.local.set(data);
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async performRealAirdropScan(data, sendResponse) {
        try {
            const { address } = data;
            console.log('Background: Performing real airdrop scan for', address);
            // First try to ask the active tab's content script (which bridges to the injected page script)
            try {
                const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tabs[0]) {
                    const tabId = tabs[0].id;
                    const response = await new Promise((resolve) => {
                        chrome.tabs.sendMessage(tabId, { action: 'scanRealAirdrops', data: { address } }, (resp) => {
                            if (chrome.runtime.lastError) {
                                console.log('Error messaging content script for scanRealAirdrops:', chrome.runtime.lastError.message);
                                resolve(null);
                            } else {
                                resolve(resp);
                            }
                        });
                    });

                    if (response && response.success && Array.isArray(response.airdrops)) {
                        await chrome.storage.local.set({ lastScanResults: response.airdrops, lastScanTime: Date.now() });
                        sendResponse({ success: true, airdrops: response.airdrops, timestamp: Date.now() });
                        return;
                    }
                }
            } catch (err) {
                console.log('Content script delegate for real scan failed:', err);
            }

            // Fallback to background heuristics
            const airdrops = await this.scanMultipleAirdropSources(address);
            await chrome.storage.local.set({ lastScanResults: airdrops, lastScanTime: Date.now() });
            sendResponse({ success: true, airdrops, timestamp: Date.now() });
        } catch (error) {
            console.error('Real airdrop scan failed:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async scanMultipleAirdropSources(address) {
        const allAirdrops = [];
        
        // 1. Check token balances (implemented in injected script)
        // 2. Check known airdrop databases
        try {
            const knownAirdrops = await this.checkKnownAirdropDatabases(address);
            allAirdrops.push(...knownAirdrops);
        } catch (error) {
            console.log('Failed to check known airdrops:', error);
        }
        
        // 3. Check DeFi protocol rewards
        try {
            const defiRewards = await this.checkDeFiProtocolRewards(address);
            allAirdrops.push(...defiRewards);
        } catch (error) {
            console.log('Failed to check DeFi rewards:', error);
        }
        
        return allAirdrops;
    }

    async checkKnownAirdropDatabases(address) {
        // In a real implementation, this would query:
        // - Airdrop databases like DefiPulse, CoinGecko, etc.
        // - Project announcement APIs
        // - Community-maintained airdrop lists
        
        const knownAirdrops = [];
        
        // Example: Check if address is eligible for common BSC airdrops
        // This would be replaced with actual API calls
        const mockAirdrops = [
            {
                id: 'pancakeswap-retrospective',
                name: 'PancakeSwap Retrospective Airdrop',
                amount: '0.00',
                symbol: 'CAKE',
                claimable: false,
                description: 'Potential CAKE airdrop for early PancakeSwap users',
                apy: 'Unknown',
                category: 'Potential',
                source: 'Community'
            }
        ];
        
        knownAirdrops.push(...mockAirdrops);
        return knownAirdrops;
    }

    async checkDeFiProtocolRewards(address) {
        // In a real implementation, this would check:
        // - Venus Protocol rewards
        // - Alpaca Finance rewards
        // - BSC DeFi protocols for unclaimed rewards
        
        const defiRewards = [];
        
        // Example: Mock DeFi rewards check
        const mockRewards = [
            {
                id: 'venus-lending-rewards',
                name: 'Venus Lending Rewards',
                amount: '0.00',
                symbol: 'XVS',
                claimable: false,
                description: 'Potential XVS rewards from Venus Protocol',
                apy: 'Variable',
                category: 'DeFi',
                source: 'Venus Protocol'
            }
        ];
        
        defiRewards.push(...mockRewards);
        return defiRewards;
    }

    async performPeriodicScan() {
        try {
            const settings = await chrome.storage.local.get(['autoScanEnabled', 'connectedWallet']);
            if (!settings.autoScanEnabled || !settings.connectedWallet?.address) {
                console.log('Periodic scan skipped: Auto-scan disabled or no wallet connected');
                return;
            }

            const airdrops = await this.scanForAirdrops(settings.connectedWallet.address);
            const lastResults = await chrome.storage.local.get('lastScanResults');
            const newAirdrops = this.findNewAirdrops(airdrops, lastResults.lastScanResults || []);

            if (newAirdrops.length > 0) {
                this.showAirdropNotification(newAirdrops);
            }

            await chrome.storage.local.set({
                lastScanResults: airdrops,
                lastScanTime: Date.now(),
            });
        } catch (error) {
            console.error('Periodic scan failed:', error);
        }
    }

    async scanForAirdrops(address) {
        try {
            // Demo airdrops for screenshots
            return [
                {
                    id: 'pancakeswap-airdrop',
                    name: 'PancakeSwap Airdrop',
                    amount: '125.50',
                    symbol: 'CAKE',
                    claimable: true,
                    description: 'Free CAKE tokens for active traders',
                    apy: '18.5%',
                    category: 'Airdrop'
                },
                {
                    id: 'bsc-ecosystem-rewards',
                    name: 'BSC Ecosystem Rewards',
                    amount: '89.75',
                    symbol: 'BNB',
                    claimable: true,
                    description: 'Rewards for BSC ecosystem participation',
                    apy: '12.8%',
                    category: 'Ecosystem'
                },
                {
                    id: 'defi-yield-farming',
                    name: 'DeFi Yield Farming',
                    amount: '267.30',
                    symbol: 'BUSD',
                    claimable: false,
                    description: 'Locked yield farming rewards (unlocks in 3 days)',
                    apy: '24.1%',
                    category: 'Yield'
                }
            ];
        } catch (error) {
            console.error('Background scan failed:', error);
            return [];
        }
    }

    findNewAirdrops(currentAirdrops, previousAirdrops) {
        const previousIds = new Set(previousAirdrops.map((r) => r.id));
        return currentAirdrops.filter((airdrop) => !previousIds.has(airdrop.id));
    }

    async getAirdropHistory(sendResponse) {
        try {
            const data = await chrome.storage.local.get(['claimedAirdrops', 'lastScanResults', 'lastScanTime']);
            sendResponse({
                success: true,
                history: {
                    claimed: data.claimedAirdrops || [],
                    lastScan: data.lastScanResults || [],
                    lastScanTime: data.lastScanTime || 0,
                },
            });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async updateClaimedAirdrops(data, sendResponse) {
        try {
            const { rewardId, transactionSignature, amount, symbol } = data;
            const storage = await chrome.storage.local.get('claimedAirdrops');
            const claimedAirdrops = storage.claimedAirdrops || [];

            claimedAirdrops.push({
                id: rewardId,
                signature: transactionSignature,
                amount,
                symbol,
                claimedAt: Date.now(),
            });

            await chrome.storage.local.set({ claimedAirdrops });
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async performDailyCleanup() {
        try {
            const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
            const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
            const data = await chrome.storage.local.get(['claimedAirdrops', 'lastScanResults']);

            const recentClaimed = (data.claimedAirdrops || []).filter(
                (airdrop) => airdrop.claimedAt > thirtyDaysAgo,
            );

            await chrome.storage.local.set({
                claimedAirdrops: recentClaimed,
            });

            console.log('Daily cleanup completed');
        } catch (error) {
            console.error('Daily cleanup failed:', error);
        }
    }

    showWelcomeNotification() {
        chrome.notifications.create('dropx-welcome', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'Welcome to DropX!',
            message: 'Start discovering free airdrops and rewards on BNB Smart Chain.',
        });
    }

    showAirdropNotification(newAirdrops) {
        const count = newAirdrops.length;
        const message = count === 1 ? `New airdrop: ${newAirdrops[0].name}` : `${count} new airdrops found!`;
        chrome.notifications.create('dropx-new-airdrops', {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'New Airdrops Available!',
            message,
        });
    }
}

new DropXBackground();