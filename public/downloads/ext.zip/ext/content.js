// Content script for DropX Extension - BNB Smart Chain
class DropXContent {
    constructor() {
        this.wallet = null;
        this.web3 = null;
        this.init();
    }

    init() {
    this.injectWalletScript();
    this.setupMessageListener();
    console.log('DropX Content Script initialized for BNB Smart Chain');
    }

    injectWalletScript() {
    const scriptId = 'dropx-injected-script';
        if (document.getElementById(scriptId)) {
            console.log('Injected script already present');
            return;
        }

        const script = document.createElement('script');
        script.id = scriptId;
        script.src = chrome.runtime.getURL('injected-standalone.js');
        script.onload = () => {
            console.log('DropX injected script loaded');
            script.remove();
        };
        (document.head || document.documentElement).appendChild(script);
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // Keep message channel open for async responses
        });
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'checkWallet':
                    await this.checkWallet(sendResponse);
                    break;
                case 'connectWallet':
                    await this.connectWallet(sendResponse);
                    break;
                case 'disconnectWallet':
                    await this.disconnectWallet(sendResponse);
                    break;
                case 'getRealBalance':
                    await this.getRealBalance(message.data, sendResponse);
                    break;
                case 'scanRealAirdrops':
                    await this.scanRealAirdrops(message.data, sendResponse);
                    break;
                case 'scanAirdrops':
                    await this.scanAirdrops(message.data, sendResponse);
                    break;
                case 'claimAirdrop':
                    await this.claimAirdrop(message.data, sendResponse);
                    break;
                case 'sendAirdrop':
                    await this.sendAirdrop(message.data, sendResponse);
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('DropX error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async checkWallet(sendResponse) {
        const result = await this.executeInPageContext('checkWalletConnection');
        sendResponse(result);
    }

    async connectWallet(sendResponse) {
        try {
            console.log('Content script: connectWallet called');
            
            // Wait for injected script to be ready
            let retries = 0;
            const maxRetries = 10;
            
            while (!window.DropXInjected && retries < maxRetries) {
                console.log(`Waiting for DropX injected script... attempt ${retries + 1}`);
                await new Promise(resolve => setTimeout(resolve, 500));
                retries++;
            }
            
            if (!window.DropXInjected) {
                throw new Error('DropX injected script not found. Please refresh the page.');
            }
            
            const result = await this.executeInPageContext('connectWallet');
            console.log('Content script: connectWallet result:', result);
            
            if (result.success) {
                this.wallet = {
                    address: result.address,
                    walletName: result.walletName,
                };
                
                // Store connection info
                try {
                    await chrome.storage.local.set({ 
                        connectedWallet: this.wallet 
                    });
                } catch (storageError) {
                    console.log('Failed to store wallet info:', storageError);
                }
                
                sendResponse({
                    success: true,
                    address: result.address,
                    balance: 0, // Will be fetched separately
                    walletName: result.walletName,
                    connected: true
                });
            } else {
                throw new Error(result.error || 'Failed to connect wallet');
            }
        } catch (error) {
            console.error('Content script connectWallet error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async disconnectWallet(sendResponse) {
        try {
            await this.executeInPageContext('disconnectWallet');
            this.wallet = null;
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async getRealBalance(data, sendResponse) {
        try {
            const result = await this.executeInPageContext('getRealBalance', data);
            // If injected script returned demo data, pass it through unchanged
            sendResponse(result);
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async scanRealAirdrops(data, sendResponse) {
        try {
            const result = await this.executeInPageContext('scanForRealAirdrops', data);
            // Pass demo rewards through when available
            sendResponse(result);
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async scanAirdrops(data, sendResponse) {
        try {
            const address = data.address;
            const airdrops = await this.fetchAirdrops(address);
            sendResponse({
                success: true,
                airdrops: airdrops,
            });
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to scan airdrops: ' + error.message,
            });
        }
    }

    async fetchAirdrops(address) {
        try {
            // Ask the injected page script to scan for real airdrops (token balances & heuristics)
            try {
                const result = await this.executeInPageContext('scanForRealAirdrops', { address });
                if (result && result.success && Array.isArray(result.airdrops)) {
                    return result.airdrops;
                }
            } catch (err) {
                console.log('Page-context airdrop scan failed, falling back to background heuristics:', err);
            }

            // Fallback: use existing background heuristics via the content script (could be extended)
            return [];
        } catch (error) {
            console.error('Failed to fetch airdrops:', error);
            return [];
        }
    }

    async claimAirdrop(data, sendResponse) {
        try {
            const { rewardId, address } = data;
            const result = await this.executeInPageContext('claimAirdrop', {
                rewardId,
                address,
            });

            if (result.success) {
                const newBalance = await this.getBNBBalance(address);
                sendResponse({
                    success: true,
                    transaction: result.transaction,
                    newBalance: newBalance,
                });
            } else {
                throw new Error(result.error || 'Failed to claim airdrop');
            }
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to claim airdrop: ' + error.message,
            });
        }
    }

    async sendAirdrop(data, sendResponse) {
        try {
            const { rewardId, recipientAddress, amount, address } = data;
            const result = await this.executeInPageContext('sendAirdrop', {
                rewardId,
                recipientAddress,
                amount,
                address,
            });

            if (result.success) {
                const newBalance = await this.getBNBBalance(address);
                sendResponse({
                    success: true,
                    transaction: result.transaction,
                    newBalance: newBalance,
                });
            } else {
                throw new Error(result.error || 'Failed to send airdrop');
            }
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to send airdrop: ' + error.message,
            });
        }
    }

    clearAirdrops() {
        this.rewards = [];
        document.getElementById('airdropContent').innerHTML = `
            <div class="no-airdrops">
                Connect wallet and scan to find available airdrops
            </div>
        `;
    }

    truncateAddress(address) {
        return `${address.slice(0, 4)}...${address.slice(-4)}`;
    }

    async sendMessageToBackground(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action, data }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    async sendMessageToContent(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action, data }, (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(response);
                        }
                    });
                } else {
                    reject(new Error('No active tab found'));
                }
            });
        });
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 12px 16px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
        `;

        switch (type) {
            case 'success':
                notification.style.background = '#2ed573';
                break;
            case 'error':
                notification.style.background = '#ff4757';
                break;
            case 'info':
                notification.style.background = '#3742fa';
                break;
            default:
                notification.style.background = '#747d8c';
        }

        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Add this method to ClaimXContent
    async executeInPageContext(action, data = {}) {
        return new Promise((resolve) => {
            const messageId = 'dropx-' + Math.random().toString(36).substr(2, 9);
            function handleResponse(event) {
                if (
                    event.source === window &&
                    event.data.type === 'DROPX_RESPONSE' &&
                    event.data.messageId === messageId
                ) {
                    window.removeEventListener('message', handleResponse);
                    resolve(event.data);
                }
            }
            window.addEventListener('message', handleResponse);
            window.postMessage({
                type: 'DROPX_REQUEST',
                action,
                data,
                messageId,
            }, '*');
        });
    }
}

new DropXContent();
