// Content script for Aster DEX Extension - BNB Smart Chain
class AsterDEXContent {
    constructor() {
        this.wallet = null;
        this.web3 = null;
        this.init();
    }

    init() {
        this.injectWalletScript();
        this.setupMessageListener();
        console.log('AsterDEX Content Script initialized for BNB Smart Chain');
    }

    injectWalletScript() {
        const scriptId = 'asterdex-injected-script';
        if (document.getElementById(scriptId)) {
            console.log('Injected script already present');
            return;
        }

        const script = document.createElement('script');
        script.id = scriptId;
        script.src = chrome.runtime.getURL('injected-standalone.js');
        script.onload = () => {
            console.log('Aster DEX injected script loaded');
            script.remove();
        };
        (document.head || document.documentElement).appendChild(script);
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // Keep message channel open for async responses
        });
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'checkWallet':
                    await this.checkWallet(sendResponse);
                    break;
                case 'connectWallet':
                    await this.connectWallet(sendResponse);
                    break;
                case 'disconnectWallet':
                    await this.disconnectWallet(sendResponse);
                    break;
                case 'scanRewards':
                    await this.scanRewards(message.data, sendResponse);
                    break;
                case 'claimReward':
                    await this.claimReward(message.data, sendResponse);
                    break;
                case 'sendReward':
                    await this.sendReward(message.data, sendResponse);
                    break;
                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('AsterDEX error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async checkWallet(sendResponse) {
        const result = await this.executeInPageContext('checkWalletConnection');
        sendResponse(result);
    }

    async connectWallet(sendResponse) {
        try {
            const result = await this.executeInPageContext('connectWallet');
            if (result.success) {
                this.wallet = {
                    address: result.address,
                    walletName: result.walletName,
                };
                sendResponse({
                    success: true,
                    address: result.address,
                    balance: 2.4567, // Demo balance
                    walletName: result.walletName,
                });
            } else {
                throw new Error(result.error || 'Failed to connect wallet');
            }
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async disconnectWallet(sendResponse) {
        try {
            await this.executeInPageContext('disconnectWallet');
            this.wallet = null;
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }

    async getBNBBalance(address) {
        try {
            // Demo balance for screenshots
            return 2.4567;
        } catch (error) {
            console.error('Failed to fetch balance:', error);
            return 0;
        }
    }

    async scanRewards(data, sendResponse) {
        try {
            const address = data.address;
            const rewards = await this.fetchRewards(address);
            sendResponse({
                success: true,
                rewards: rewards,
            });
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to scan rewards: ' + error.message,
            });
        }
    }

    async fetchRewards(address) {
        try {
            // Demo rewards data for screenshots
            return [
                {
                    id: 'aster-trading-rewards',
                    name: 'Trading Volume Rewards',
                    amount: '72.50',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Earned from perpetual trading volume',
                    apy: '24.5%',
                    category: 'Trading'
                },
                {
                    id: 'liquidity-mining',
                    name: 'Liquidity Mining',
                    amount: '45.25',
                    symbol: 'ASTER',
                    claimable: true,
                    description: 'Rewards for providing liquidity',
                    apy: '18.2%',
                    category: 'Liquidity'
                },
                {
                    id: 'staking-rewards',
                    name: 'ASTER Staking',
                    amount: '156.80',
                    symbol: 'ASTER',
                    claimable: false,
                    description: 'Locked staking rewards (unlocks in 7 days)',
                    apy: '32.1%',
                    category: 'Staking'
                }
            ];
        } catch (error) {
            console.error('Failed to fetch rewards:', error);
            return [];
        }
    }

    async claimReward(data, sendResponse) {
        try {
            const { rewardId, address } = data;
            const result = await this.executeInPageContext('claimReward', {
                rewardId,
                address,
            });

            if (result.success) {
                const newBalance = await this.getBNBBalance(address);
                sendResponse({
                    success: true,
                    transaction: result.transaction,
                    newBalance: newBalance,
                });
            } else {
                throw new Error(result.error || 'Failed to claim reward');
            }
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to claim reward: ' + error.message,
            });
        }
    }

    async sendReward(data, sendResponse) {
        try {
            const { rewardId, recipientAddress, amount, address } = data;
            const result = await this.executeInPageContext('sendReward', {
                rewardId,
                recipientAddress,
                amount,
                address,
            });

            if (result.success) {
                const newBalance = await this.getBNBBalance(address);
                sendResponse({
                    success: true,
                    transaction: result.transaction,
                    newBalance: newBalance,
                });
            } else {
                throw new Error(result.error || 'Failed to send reward');
            }
        } catch (error) {
            sendResponse({
                success: false,
                error: 'Failed to send reward: ' + error.message,
            });
        }
    }

    clearRewards() {
        this.rewards = [];
        document.getElementById('airdropContent').innerHTML = `
            <div class="no-airdrops">
                Connect wallet and scan to find available rewards
            </div>
        `;
    }

    truncateAddress(address) {
        return `${address.slice(0, 4)}...${address.slice(-4)}`;
    }

    async sendMessageToBackground(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action, data }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    async sendMessageToContent(action, data = {}) {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, { action, data }, (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(response);
                        }
                    });
                } else {
                    reject(new Error('No active tab found'));
                }
            });
        });
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 12px 16px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
        `;

        switch (type) {
            case 'success':
                notification.style.background = '#2ed573';
                break;
            case 'error':
                notification.style.background = '#ff4757';
                break;
            case 'info':
                notification.style.background = '#3742fa';
                break;
            default:
                notification.style.background = '#747d8c';
        }

        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // Add this method to ClaimXContent
    async executeInPageContext(action, data = {}) {
        return new Promise((resolve) => {
            const messageId = 'asterdx-' + Math.random().toString(36).substr(2, 9);
            function handleResponse(event) {
                if (
                    event.source === window &&
                    event.data.type === 'ASTERDX_RESPONSE' &&
                    event.data.messageId === messageId
                ) {
                    window.removeEventListener('message', handleResponse);
                    resolve(event.data);
                }
            }
            window.addEventListener('message', handleResponse);
            window.postMessage({
                type: 'ASTERDX_REQUEST',
                action,
                data,
                messageId,
            }, '*');
        });
    }
}

new AsterDEXContent();
