# DropX Extension Troubleshooting

## Wallet Connection Issues

If you're experiencing problems connecting your wallet, please follow these steps:

### 1. **Extension Setup**
1. **Reload the Extension**:
   - Go to `chrome://extensions/`
   - Find "DropX - Free BSC Airdrop Discovery Tool"
   - Click the reload button (🔄)

2. **Refresh the Page**:
   - After reloading the extension, refresh the current page (F5)
   - The extension needs to re-inject its scripts

### 2. **MetaMask Setup**
1. **Install MetaMask**: Make sure MetaMask is installed and unlocked
2. **Add BNB Smart Chain Network** (if not already added):
   - Network Name: `BNB Smart Chain`
   - RPC URL: `https://bsc-dataseed.binance.org/`
   - Chain ID: `56`
   - Symbol: `BNB`
   - Block Explorer: `https://bscscan.com`

### 3. **Test Connection Steps**
1. Open the DropX extension popup
2. Click "Connect Wallet"
3. Allow MetaMask connection when prompted
4. The extension should automatically switch to BSC network

### 4. **Common Issues & Solutions**

#### Error: "DropX injected script not found"
**Solution**: Refresh the page after reloading the extension

#### Error: "Could not establish connection"
**Solution**: 
1. Reload the extension
2. Refresh the page
3. Try connecting again

#### Error: "No Web3 wallet detected"
**Solution**: 
1. Install MetaMask from https://metamask.io
2. Unlock your MetaMask wallet
3. Refresh the page

#### Extension shows "Connecting..." but never connects
**Solution**:
1. Check if MetaMask popup is blocked
2. Make sure MetaMask is unlocked
3. Try connecting directly in MetaMask first
4. Refresh the page and try again

### 5. **Testing on Different Pages**
The extension works best on:
- ✅ **BSC DeFi sites** (PancakeSwap, Venus, etc.)
- ✅ **DEX platforms**
- ✅ **Any HTTPS website**
- ❌ Chrome extension pages (like chrome://extensions/)
- ❌ Local file:// pages

### 6. **Debug Mode**
To see detailed connection logs:
1. Right-click on the page → "Inspect"
2. Go to "Console" tab
3. Try connecting wallet
4. Check for any error messages

### 7. **Reset Steps**
If nothing works:
1. Disable the DropX extension
2. Close and reopen Chrome
3. Enable the DropX extension
4. Go to a BSC-compatible website (like pancakeswap.finance)
5. Try connecting again